import tkinter as tk
from ui import App

if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
