Hello, Thank you for trying this out.
I am refreshing the code as I am still learning python. 
Run Main.py and it should work as intended, there are a decent amount of bugs, so please let me know what they are.
