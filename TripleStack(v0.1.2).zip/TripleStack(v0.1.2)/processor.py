import shutil
from pathlib import Path
from PIL import Image
from ini_utils import update_skin_ini
from image_utils import stack_overlay, trim_transparency


def delete_2x_assets(skin_dir: Path):
    for f in skin_dir.iterdir():
        if '@2x' in f.name.lower():
            try:
                f.unlink()
            except FileNotFoundError:
                pass

def triple_stack_skin(skin_dir: Path, overlay_file="hitcircleoverlay.png"):
    overlay_path = skin_dir / overlay_file
    if not overlay_path.exists():
        return

    with Image.open(overlay_path) as overlay:
        overlay = overlay.convert('RGBA')
        overlay = trim_transparency(overlay)

        # Stack onto numbered default hitcircles
        for img_path in skin_dir.glob("default-?[0-9].png"):
            with Image.open(img_path) as base:
                base = base.convert('RGBA')
                out = stack_overlay(base, overlay)
                out.save(img_path)

        # Stack onto hitcircle.png itself
        hitcircle_path = skin_dir / "hitcircle.png"
        if hitcircle_path.exists():
            with Image.open(hitcircle_path) as hi:
                hi = hi.convert('RGBA')
                scaled_overlay = overlay.resize(hi.size, Image.NEAREST)
                hi.paste(scaled_overlay, (0, 0), scaled_overlay)
                hi.save(hitcircle_path)


def copy_and_process(src: Path, do_copy: bool):
    dst = src
    if do_copy:
        base_name = f"{src.name}@3xStack"
        dst = src.parent / base_name
        i = 1
        while dst.exists():
            dst = src.parent / f"{base_name}({i})"
            i += 1
        shutil.copytree(src, dst)
    delete_2x_assets(dst)
    triple_stack_skin(dst)
    update_skin_ini(dst)
    return dst

