import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
from PIL import Image, ImageTk
from image_utils import stack_overlay, make_pattern
from processor import copy_and_process

class App(ttk.Frame):
    def __init__(self, root):
        super().__init__(root, padding=10)
        root.title("Triple Stack Skin Maker")
        root.geometry("520x480")
        self.skin_path = None
        self.orig_img = self.pre_img = None
        self.copy_var = tk.BooleanVar(value=True)
        self.ovr_var  = tk.BooleanVar(value=False)

        self.pos_to_val = {
            0: "Native",
            1: 100,
            2: 110,
            3: 120,
            4: 130,
            5: 140,
            6: 150,
            7: 160,
        }
        self.val_to_pos = {v: k for k, v in self.pos_to_val.items()}
        self.res_pos_var = tk.IntVar(value=0)
        self._build_ui()
        self.pack(fill='both', expand=True)

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('.', background='#2e2e2e', foreground='#fff')

        ttk.Label(self, text="Triple Stack Skin Maker",
                  font=('Segoe UI',14,'bold')).pack(pady=(0,6))
        ttk.Label(self, text="Back up first! Deletes @2x, stacks defaults & hitcircle, updates skin.ini.",
                  wraplength=500, justify='center').pack(pady=(0,8))

        self.opt_btn = ttk.Button(self, text="Options ▼", command=self._toggle_opts)
        self.opt_btn.pack()
        self.opts = ttk.Labelframe(self, text="Options", padding=8)
        row_frame = ttk.Frame(self.opts)
        row_frame.pack(pady=4)

        ttk.Checkbutton(row_frame, text="Copy & Process", variable=self.copy_var).pack(side='left', padx=10)
        ttk.Checkbutton(row_frame, text="Force Overlay Res", variable=self.ovr_var).pack(side='left', padx=10)
        # Resolution row (label + slider + value)
        res_frame = ttk.Frame(self.opts)
        res_frame.pack(pady=(8, 4))

        ttk.Label(res_frame, text="Resolution:").pack(side='left', padx=(10, 5))

        self.scale = tk.Scale(res_frame, from_=0, to=7, orient='horizontal',
                      variable=self.res_pos_var, length=180,
                      showvalue=False, tickinterval=1, sliderrelief='flat')
        self.scale.pack(side='left', padx=5)

        self.res_label = ttk.Label(res_frame, text=self.pos_to_val[self.res_pos_var.get()])
        self.res_label.pack(side='left', padx=(5, 10))

        self.res_pos_var.trace_add('write', lambda *a: self._update_slider_label())
        self.ovr_var.trace_add('write', lambda *a: self.update_preview())

        bar = ttk.Frame(self); bar.pack(pady=(8,12))
        pat = make_pattern(120,40,'#ff66cc','#e055b3',10)
        for txt, cmd in [("Select Skin", self.select_skin),
                         ("Confirm",     self.confirm)]:
            btn = tk.Button(bar, text=txt, image=pat, compound='center',
                            bd=0, command=cmd)
            btn.image = pat
            btn.pack(side='left', padx=8)
            if txt=="Confirm":
                self.confirm_btn = btn
                btn.config(state='disabled')

        self.canvas = tk.Canvas(self, bg='#2e2e2e',
                                highlightthickness=2, highlightbackground='#ff66cc')
        self.canvas.pack(fill='both', expand=True)
        self.canvas.bind('<Configure>', lambda e: self._draw_canvas())

        self.res_pos_var.trace_add('write', lambda *a: self._update_slider_label())

    def _update_slider_label(self): 
        self.res_label.config(text=self.pos_to_val[self.res_pos_var.get()])
        self.update_preview()


    def _on_res_change(self, *args):
        val = self.pos_to_val[self.res_pos_var.get()]
        self.res_label.config(text=str(val))
        self.update_preview()

    def _toggle_opts(self):
        if self.opts.winfo_ismapped():
            self.opts.pack_forget()
            self.opt_btn.config(text="Options ▼")
        else:
            self.opts.pack(fill='x', padx=60, pady=6, after=self.opt_btn)
            self.opt_btn.config(text="Options ▲")

    def _draw_canvas(self):
        self.canvas.delete('all')
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        for y in range(0, h, 20):
            for x in range(0, w, 20):
                self.canvas.create_polygon(
                    x, y+20, x+10, y, x+20, y+20,
                    fill='#444', outline='#2e2e2e'
                )
        if self.orig_img and self.pre_img:
            x1, x2 = w * 0.25, w * 0.75
            cy = h / 2
            self.canvas.create_image(x1, cy, image=self.orig_img, anchor='center')
            self.canvas.create_image(x2, cy, image=self.pre_img,  anchor='center')
            label_y1 = cy - (self.orig_img.height()/2) - 8
            label_y2 = cy - (self.pre_img.height()/2) - 8
            self.canvas.create_text(x1, label_y1, text='Before', anchor='center', fill='#fff')
            self.canvas.create_text(x2, label_y2, text='After',  anchor='center', fill='#fff')

    def select_skin(self):
        d = filedialog.askdirectory(title="Select osu! Skin Folder")
        if not d: return
        self.skin_path = Path(d)
        self.confirm_btn.config(state='normal')
        self.update_preview()

    def update_preview(self):
        p = self.skin_path
        if not p: return
        orig_f, ov_f = p/"hitcircle.png", p/"hitcircleoverlay.png"
        if not (orig_f.exists() and ov_f.exists()): return
        o = Image.open(orig_f).convert('RGBA')
        ov = Image.open(ov_f).convert('RGBA')
        if self.ovr_var.get():
            r = self.pos_to_val[self.res_pos_var.get()]
            if r != "Native":
                ov = ov.resize((int(r), int(r)), Image.NEAREST)
        comp = stack_overlay(o, ov, o.size)
        self.orig_img = ImageTk.PhotoImage(o)
        self.pre_img  = ImageTk.PhotoImage(comp)
        self._draw_canvas()

    def confirm(self):
        out = copy_and_process(self.skin_path, self.copy_var.get())
        messagebox.showinfo("Done", f"Processed → {out}")
        self.confirm_btn.config(state='disabled')


if __name__ == "__main__":
    root = tk.Tk()
    App(root).pack(fill='both', expand=True)
    root.mainloop()
